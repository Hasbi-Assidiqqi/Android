package com.android.githubuserapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

public class InfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);

        LinearLayout llPhone = findViewById(R.id.ll_phone);
        llPhone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (view.getId() == R.id.ll_phone) {
                    String phoneNumber = "081373721975";
                    Intent dialPhone = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"+phoneNumber));
                    startActivity(dialPhone);
                }
            }
        });
    }

    public void onProcess(View view) {
        Toast.makeText(this, "Maaf, Fitur sedang dikembangkan", Toast.LENGTH_SHORT).show();
    }
}