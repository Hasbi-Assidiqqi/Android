package com.android.githubuserapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import com.android.githubuserapp.adapter.UserAdapter;
import com.android.githubuserapp.model.User;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ArrayList<User> usersList;
    private UserAdapter adapter;
    private TypedArray dataAvatar;
    private String[] dataUsername;
    private String[] dataName;
    private String[] dataFollowers;
    private String[] dataFollowing;
    private String[] dataCompany;
    private String[] dataLocation;
    private String[] dataRepository;
    private static long backPressed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView listView = findViewById(R.id.lv_list);
        adapter = new UserAdapter(this);
        listView.setAdapter(adapter);

        prepare();
        addItem();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent clickItem = new Intent(MainActivity.this, DetailActivity.class);
                clickItem.putExtra(DetailActivity.EXTRA_PERSON, usersList.get(i));

                startActivity(clickItem);
            }
        });

        ImageButton btnImage = findViewById(R.id.btn_image);
        btnImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (view.getId() == R.id.btn_image) {
                    Intent moveInfo = new Intent(MainActivity.this, InfoActivity.class);
                    startActivity(moveInfo);
                }
            }
        });
    }

    private void prepare() {
        dataAvatar = getResources().obtainTypedArray(R.array.avatar);
        dataUsername = getResources().getStringArray(R.array.username);
        dataName = getResources().getStringArray(R.array.name);
        dataFollowers = getResources().getStringArray(R.array.followers);
        dataFollowing = getResources().getStringArray(R.array.following);
        dataCompany= getResources().getStringArray(R.array.company);
        dataLocation = getResources().getStringArray(R.array.location);
        dataRepository = getResources().getStringArray(R.array.repository);
    }

    private void addItem() {
        usersList = new ArrayList<>();
        for (int i = 0; i < dataName.length; i++) {
            User user = new User();
            user.setAvatar(dataAvatar.getResourceId(i, -1));
            user.setUsername(dataUsername[i]);
            user.setName(dataName[i]);
            user.setFollowers(dataFollowers[i]);
            user.setFollowing(dataFollowing[i]);
            user.setCompany(dataCompany[i]);
            user.setLocation(dataLocation[i]);
            user.setRepository(dataRepository[i]);
            usersList.add(user);
        }
        adapter.setUsers(usersList);
    }

    public void onProcess(View view) {
        Toast.makeText(this, "Maaf, Fitur sedang dikembangkan", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onBackPressed() {
        if (backPressed + 2000 > System.currentTimeMillis()) {
            super.onBackPressed();
            finish();
        } else {
            Toast.makeText(getBaseContext(), "Press back again to exit!", Toast.LENGTH_SHORT).show();
        }

        backPressed = System.currentTimeMillis();
    }
}