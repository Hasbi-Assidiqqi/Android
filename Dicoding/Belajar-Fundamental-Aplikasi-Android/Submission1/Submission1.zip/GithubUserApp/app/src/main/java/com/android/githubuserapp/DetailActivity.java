package com.android.githubuserapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.githubuserapp.model.User;

import java.util.Objects;

public class DetailActivity extends AppCompatActivity {
    public static final String EXTRA_PERSON = "extra_person";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        ImageView imgAvatar = findViewById(R.id.img_avatar_detail);
        TextView tvUsername = findViewById(R.id.tv_username_detail);
        TextView tvName = findViewById(R.id.tv_name_detail);
        TextView tvFollowers= findViewById(R.id.tv_followers);
        TextView tvFollowing = findViewById(R.id.tv_following);
        TextView tvCompany = findViewById(R.id.tv_company);
        TextView tvLocation = findViewById(R.id.tv_location);
        TextView tvRepository = findViewById(R.id.tv_repository);

        User user = getIntent().getParcelableExtra(EXTRA_PERSON);

        imgAvatar.setImageResource(Objects.requireNonNull(user).getAvatar());
        tvUsername.setText(user.getUsername());
        tvName.setText(user.getName());
        tvFollowers.setText(user.getFollowers());
        tvFollowing.setText(user.getFollowing());
        tvCompany.setText(user.getCompany());
        tvLocation.setText(user.getLocation());
        tvRepository.setText(user.getRepository());
    }
}