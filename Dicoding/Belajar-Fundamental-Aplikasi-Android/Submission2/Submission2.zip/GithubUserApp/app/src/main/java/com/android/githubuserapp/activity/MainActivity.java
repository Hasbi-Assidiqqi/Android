package com.android.githubuserapp.activity;

import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.githubuserapp.R;
import com.android.githubuserapp.adapter.UserAdapter;
import com.android.githubuserapp.api.ApiClient;
import com.android.githubuserapp.model.ResponseUser;
import com.android.githubuserapp.model.UserModel;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    List<UserModel> dataGithub = new ArrayList<>();
    RecyclerView rvUser;
    private static long backPressed;
    private ProgressBar progressBar;
    private ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        progressBar = findViewById(R.id.progressBar);
        imageView = findViewById(R.id.image);
        rvUser = findViewById(R.id.rv_search_user);

        rvUser.setLayoutManager(new LinearLayoutManager(MainActivity.this));

        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        if (searchManager != null) {
            final SearchView searchView = findViewById(R.id.searcView);
            searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
            searchView.setQueryHint(getResources().getString(R.string.username));
            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String string) {
                    showProgress(true);
                    if (string.isEmpty()) {
                        Toast.makeText(MainActivity.this, R.string.desc_empty, Toast.LENGTH_SHORT).show();
                    } else {
                        getDataOnline(string);
                        closeKeyboard();
                    }
                    return true;
                }

                @Override
                public boolean onQueryTextChange(String s) {
                    return true;
                }
            });
        }

        ImageButton btnImage = findViewById(R.id.btn_image);
        btnImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    Intent moveInfo = new Intent(MainActivity.this, InfoActivity.class);
                    startActivity(moveInfo);
            }
        });

        ImageButton tvLanguage = findViewById(R.id.btn_change_language);
        tvLanguage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    Intent mIntent = new Intent(Settings.ACTION_LOCALE_SETTINGS);
                    startActivity(mIntent);
            }
        });
    }

    private void showProgress(Boolean state) {
        if (state) {
            progressBar.setVisibility(View.VISIBLE);
            rvUser.setVisibility(View.GONE);
        } else {
            progressBar.setVisibility(View.GONE);
            rvUser.setVisibility(View.VISIBLE);
        }
        imageView.setVisibility(View.GONE);
    }

    private void getDataOnline(final String usernames) {
        Call<ResponseUser> request = ApiClient.getApiService().getSearchUser(usernames);
        request.enqueue(new Callback<ResponseUser>() {
            @Override
            public void onResponse(@NotNull Call<ResponseUser> call, @NotNull Response<ResponseUser> response) {
                if (response.isSuccessful()) {
                    dataGithub = Objects.requireNonNull(response.body()).getItems();
                    rvUser.setAdapter(new UserAdapter(MainActivity.this, dataGithub));
                    showProgress(false);
                } else {
                    Toast.makeText(MainActivity.this, R.string.desc_not_succes, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(@NotNull Call<ResponseUser> call, @NotNull Throwable t) {
                Toast.makeText(MainActivity.this, "Request Failure" + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (backPressed + 1000 > System.currentTimeMillis()) {
            super.onBackPressed();
            finish();
        } else {
            Toast.makeText(getBaseContext(), R.string.desc_press_again, Toast.LENGTH_SHORT).show();
        }
        backPressed = System.currentTimeMillis();
    }

    private void closeKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager inputMethodManager = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }
}
