package com.android.githubuserapp.model;

import com.google.gson.annotations.SerializedName;

public class FollowerModel{

	@SerializedName("id")
	private int id;

	@SerializedName("login")
	private String login;

	@SerializedName("avatar_url")
	private String avatarUrl;


	public void setId(int id){
		this.id = id;
	}

	public int getId(){
		return id;
	}

	public String getLogin(){
		return login;
	}

	public String getAvatarUrl(){
		return avatarUrl;
	}


	public FollowerModel(int id, String login, String avatarUrl) {
		this.id = id;
		this.login = login;
		this.avatarUrl = avatarUrl;
	}
}