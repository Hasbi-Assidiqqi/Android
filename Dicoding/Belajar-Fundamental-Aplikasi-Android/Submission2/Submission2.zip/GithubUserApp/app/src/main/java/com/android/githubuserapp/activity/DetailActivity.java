package com.android.githubuserapp.activity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.android.githubuserapp.R;
import com.android.githubuserapp.adapter.SectionsPagerAdapter;
import com.android.githubuserapp.adapter.UserAdapter;
import com.android.githubuserapp.api.ApiClient;
import com.android.githubuserapp.model.DetailModel;
import com.android.githubuserapp.model.UserModel;
import com.bumptech.glide.Glide;
import com.google.android.material.tabs.TabLayout;

import org.jetbrains.annotations.NotNull;
import org.parceler.Parcels;

import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DetailActivity extends AppCompatActivity {
    DetailModel dataDetailUser;
    UserModel dataUser;
    TextView tvName, tvUsername, tvFollowers, tvFollowing, tvLocation, tvCompany, tvRepository;
    ImageView imgAvatar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        Bundle bundle = getIntent().getBundleExtra(UserAdapter.DATA_EXTRA);
        dataUser = Parcels.unwrap(Objects.requireNonNull(bundle).getParcelable(UserAdapter.DATA_USER));

        loadData();
        tabLayout();
    }

    private void tabLayout() {
        SectionsPagerAdapter sectionsPagerAdapter = new SectionsPagerAdapter(this, getSupportFragmentManager());
        ViewPager viewPager = findViewById(R.id.view_pager);
        viewPager.setAdapter(sectionsPagerAdapter);
        TabLayout tabLayout = findViewById(R.id.tab_layout);
        tabLayout.setupWithViewPager(viewPager);
    }

    public void loadData() {
        imgAvatar = findViewById(R.id.img_avatar_detail);
        tvUsername = findViewById(R.id.tv_username_detail);
        tvName = findViewById(R.id.tv_name_detail);
        tvLocation = findViewById(R.id.tv_location_detail);
        tvFollowers = findViewById(R.id.tv_followers);
        tvFollowing = findViewById(R.id.tv_following);
        tvCompany = findViewById(R.id.tv_company_detail);
        tvRepository = findViewById(R.id.tv_repository_detail);

        final ProgressDialog progress = new ProgressDialog(DetailActivity.this);
        progress.setMessage(getString(R.string.loading));
        progress.show();

        Glide.with(DetailActivity.this)
                .load(dataUser.getAvatarUrl())
                .into(imgAvatar);
        tvUsername.setText(dataUser.getLogin());

        Call<DetailModel> request = ApiClient.getApiService().getDetailUser(dataUser.getLogin());
        request.enqueue(new Callback<DetailModel>() {
            @Override
            public void onResponse(@NotNull Call<DetailModel> call, @NotNull Response<DetailModel> response) {
                dataDetailUser = response.body();

                tvName.setText(Objects.requireNonNull(dataDetailUser).getName());

                if (dataDetailUser.getLocation() == null) {
                    tvLocation.setText(R.string.empty);
                } else {
                    tvLocation.setText(dataDetailUser.getLocation());
                }

                if (dataDetailUser.getCompany() == null) {
                    tvCompany.setText(R.string.empty);
                } else {
                    tvCompany.setText(dataDetailUser.getCompany());
                }

                if (dataDetailUser.getPublic_repos() == null) {
                    tvRepository.setText(R.string.empty);
                } else {
                    tvRepository.setText(dataDetailUser.getPublic_repos());
                }

                tvFollowers.setText(dataDetailUser.getFollowers());
                tvFollowing.setText(dataDetailUser.getFollowing());
                progress.dismiss();
            }

            @Override
            public void onFailure(@NotNull Call<DetailModel> call, @NotNull Throwable t) {
            }
        });
    }
}