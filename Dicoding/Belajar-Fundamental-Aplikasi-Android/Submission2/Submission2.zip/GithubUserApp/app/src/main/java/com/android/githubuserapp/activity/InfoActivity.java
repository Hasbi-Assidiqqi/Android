package com.android.githubuserapp.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

import com.android.githubuserapp.R;

public class InfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);

        LinearLayout llPhone = findViewById(R.id.ll_phone);
        llPhone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (view.getId() == R.id.ll_phone) {
                    String phoneNumber = "081373721975";
                    Intent dialPhone = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"+phoneNumber));
                    startActivity(dialPhone);
                }
            }
        });
    }

    public void sendEmail(View view) {
        String emailAddress = "assidiqqi.0210@gmail.com";
        String url = "mailto:" + emailAddress;
        Intent sendEmail = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(sendEmail);
    }

    public void openWhtasapp(View view) {
        String phoneNumber = "6281373721975";
        String url = "https://api.whatsapp.com/send?phone=" + phoneNumber;
        Intent chatWhatsapp = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(chatWhatsapp);
    }
}
