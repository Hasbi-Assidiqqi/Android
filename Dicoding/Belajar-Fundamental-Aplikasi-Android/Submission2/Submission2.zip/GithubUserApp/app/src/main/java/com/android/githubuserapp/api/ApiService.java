package com.android.githubuserapp.api;

import com.android.githubuserapp.model.DetailModel;
import com.android.githubuserapp.model.FollowerModel;
import com.android.githubuserapp.model.FollowingModel;
import com.android.githubuserapp.model.ResponseUser;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiService {
    @GET("search/users")
    @Headers("Authorization: token 94e8c43ebed968020e23a9eff39999fc8f08ab5f")
    Call<ResponseUser> getSearchUser(
            @Query("q") String username
    );

    @GET("users/{username}")
    @Headers("Authorization: token 94e8c43ebed968020e23a9eff39999fc8f08ab5f")
    Call<DetailModel> getDetailUser(
            @Path("username") String username
    );

    @GET("users/{username}/followers")
    @Headers("Authorization: token 94e8c43ebed968020e23a9eff39999fc8f08ab5f")
    Call<List<FollowerModel>> getFollowerUser(
            @Path("username") String username
    );

    @GET("users/{username}/following")
    @Headers("Authorization: token 94e8c43ebed968020e23a9eff39999fc8f08ab5f")
    Call<List<FollowingModel>> getFollowingUser(
            @Path("username") String username
    );
}
