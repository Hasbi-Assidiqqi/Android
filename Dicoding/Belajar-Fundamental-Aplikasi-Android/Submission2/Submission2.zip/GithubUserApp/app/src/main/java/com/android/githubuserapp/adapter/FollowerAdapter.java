package com.android.githubuserapp.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.githubuserapp.R;
import com.android.githubuserapp.model.FollowerModel;
import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class FollowerAdapter extends RecyclerView.Adapter<FollowerAdapter.FollowerViewHolder> {
    private Context context;
    private ArrayList<FollowerModel> data;

    public FollowerAdapter(Context context, ArrayList<FollowerModel> listFollower) {
        this.context = context;
        this.data = listFollower;
    }

    @NonNull
    @Override
    public FollowerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemview = LayoutInflater.from(context).inflate(R.layout.follower_item, parent, false);
        return new FollowerViewHolder(itemview);
    }

    @Override
    public void onBindViewHolder(@NonNull FollowerViewHolder holder, int position) {
        holder.tvUsernameFollower.setText(data.get(position).getLogin());
        Glide.with(context)
                .load(data.get(position).getAvatarUrl())
                .into(holder.imgAvatarFollower);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public static class FollowerViewHolder extends RecyclerView.ViewHolder {
        TextView tvUsernameFollower;
        ImageView imgAvatarFollower;

        public FollowerViewHolder(@NonNull View itemView) {
            super(itemView);
            tvUsernameFollower = itemView.findViewById(R.id.tv_username_follower);
            imgAvatarFollower = itemView.findViewById(R.id.img_avatar_follower);
        }
    }
}
