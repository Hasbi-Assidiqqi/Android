package com.android.githubuserapp.model;

import com.google.gson.annotations.SerializedName;

import org.parceler.Parcel;

@Parcel
public class UserModel{

    @SerializedName("id")
    public int id;

    @SerializedName("login")
    public String login;

    @SerializedName("avatar_url")
    public String avatarUrl;


    public void setId(int id){
        this.id = id;
    }

    public int getId(){
        return id;
    }

    public String getLogin(){
        return login;
    }

    public String getAvatarUrl(){
        return avatarUrl;
    }
}