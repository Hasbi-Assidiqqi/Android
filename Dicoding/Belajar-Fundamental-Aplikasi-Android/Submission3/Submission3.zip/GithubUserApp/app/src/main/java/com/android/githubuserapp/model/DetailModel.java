package com.android.githubuserapp.model;

import com.google.gson.annotations.SerializedName;

public class DetailModel {

	@SerializedName("id")
	private Long id;

	@SerializedName("name")
	private final String name;

	@SerializedName("location")
	private final String location;

	@SerializedName("company")
	private final String company;

	@SerializedName("public_repos")
	private final String public_repos;

	@SerializedName("followers")
	private final String followers;

	@SerializedName("following")
	private final String following;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public String getLocation() {
		return location;
	}

	public String getCompany() {
		return company;
	}

	public String getPublic_repos() {
		return public_repos;
	}

	public String getFollowers() {
		return followers;
	}

	public String getFollowing() {
		return following;
	}


	public DetailModel(String name, String location, String company, String public_repos, String followers, String following) {
		this.name = name;
		this.location = location;
		this.company = company;
		this.public_repos = public_repos;
		this.followers = followers;
		this.following = following;
	}
}