package com.android.githubuserapp.fragment;

import android.os.Bundle;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.githubuserapp.R;
import com.android.githubuserapp.activity.DetailActivity;
import com.android.githubuserapp.adapter.FollowerAdapter;
import com.android.githubuserapp.adapter.UserAdapter;
import com.android.githubuserapp.api.ApiClient;
import com.android.githubuserapp.model.FollowerModel;
import com.android.githubuserapp.model.UserModel;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.parceler.Parcels;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FollowersFragment extends Fragment {
    RecyclerView rvFollower;
    UserModel dataUser;

    public FollowersFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_followers, container, false);
    }

    @Override
    public void onViewCreated(@NotNull final View view, @Nullable Bundle savedInstanceState){
        super.onViewCreated(view, savedInstanceState);

        DetailActivity detailActivity = (DetailActivity) getActivity();
        Bundle bundle = Objects.requireNonNull(detailActivity).getIntent().getBundleExtra(UserAdapter.DATA_EXTRA);
        dataUser = Parcels.unwrap(Objects.requireNonNull(bundle).getParcelable(UserAdapter.DATA_USER));

        rvFollower = view.findViewById(R.id.rv_followers);
        rvFollower.setLayoutManager(new LinearLayoutManager(view.getContext()));

        Call<List<FollowerModel>> request = ApiClient.getApiService().getFollowerUser(dataUser.getLogin());
        request.enqueue(new Callback<List<FollowerModel>>() {
            @Override
            public void onResponse(@NotNull Call<List<FollowerModel>> call, @NotNull Response<List<FollowerModel>> response) {
                if (response.isSuccessful()){
                    if (response.body() != null){
                        ArrayList<FollowerModel> listFollower = new ArrayList<>(response.body());
                        Log.d("TAG RESULT", "onResponse: " +listFollower.size());
                        rvFollower.setAdapter(new FollowerAdapter(getContext(), listFollower));
                    }
                } else {
                    Toast.makeText(getContext(), "Request Not Success", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(@NotNull Call<List<FollowerModel>> call, @NotNull Throwable t) {
                Toast.makeText(getContext(), "Request Failure"+t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
