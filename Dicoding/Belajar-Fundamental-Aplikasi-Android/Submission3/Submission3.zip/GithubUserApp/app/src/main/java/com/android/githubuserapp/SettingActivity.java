package com.android.githubuserapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Switch;
import android.widget.Toast;

public class SettingActivity extends AppCompatActivity {
    private AlarmReceiver alarmReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        alarmReceiver = new AlarmReceiver();

        @SuppressLint("UseSwitchCompatOrMaterialCode")
        Switch swtReminder = findViewById(R.id.swt_reminder);
        swtReminder.setChecked(false);

        swtReminder.setOnCheckedChangeListener((compoundButton, b) -> {
            boolean isFavourite = readState();
            if (b) {
                alarmReceiver.setRepeatingAlarm(getApplicationContext());
                Toast.makeText(SettingActivity.this, R.string.repeat_alaram_on, Toast.LENGTH_SHORT).show();
                isFavourite = true;
                saveState(isFavourite);
            } else {
                alarmReceiver.cancelAlarm(getApplicationContext());
                Toast.makeText(SettingActivity.this, R.string.repeat_alaram_off, Toast.LENGTH_SHORT).show();
            }
        });

        if (swtReminder.isChecked()) {
            alarmReceiver.setRepeatingAlarm(getApplicationContext());
            Toast.makeText(SettingActivity.this, R.string.repeat_alaram_on, Toast.LENGTH_SHORT).show();
        } else {
            alarmReceiver.cancelAlarm(getApplicationContext());
        }
    }

    private void saveState(boolean isFavourite) {
        SharedPreferences aSharedPreferences = this.getSharedPreferences(
                "Favourite", Context.MODE_PRIVATE);
        SharedPreferences.Editor aSharedPreferencesEdit = aSharedPreferences
                .edit();
        aSharedPreferencesEdit.putBoolean("State", isFavourite);
        aSharedPreferencesEdit.apply();
    }

    private boolean readState() {
        SharedPreferences aSharedPreferences = this.getSharedPreferences(
                "Favourite", Context.MODE_PRIVATE);
        return aSharedPreferences.getBoolean("State", true);
    }
}