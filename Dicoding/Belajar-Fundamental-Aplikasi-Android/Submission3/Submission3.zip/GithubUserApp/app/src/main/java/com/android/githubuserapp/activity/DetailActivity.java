package com.android.githubuserapp.activity;

import android.app.ProgressDialog;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.android.githubuserapp.R;
import com.android.githubuserapp.adapter.SectionsPagerAdapter;
import com.android.githubuserapp.adapter.UserAdapter;
import com.android.githubuserapp.api.ApiClient;
import com.android.githubuserapp.local.FavoriteHelper;
import com.android.githubuserapp.model.DetailModel;
import com.android.githubuserapp.model.UserModel;
import com.bumptech.glide.Glide;
import com.google.android.material.tabs.TabLayout;

import org.jetbrains.annotations.NotNull;
import org.parceler.Parcels;

import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.android.githubuserapp.local.DatabaseContract.FavoritesColumns.AVATAR_URL;
import static com.android.githubuserapp.local.DatabaseContract.FavoritesColumns.CONTENT_URI;
import static com.android.githubuserapp.local.DatabaseContract.FavoritesColumns.ID_USER;
import static com.android.githubuserapp.local.DatabaseContract.FavoritesColumns.LOGIN;


public class DetailActivity extends AppCompatActivity {
    DetailModel dataDetailUser;
    UserModel dataUser;
    LinearLayout llLocation, llCompany;
    TextView tvName, tvUsername, tvFollowers, tvFollowing, tvLocation, tvCompany, tvRepository;
    ImageView imgAvatar;
    ImageButton btnAddFavorite;

    private String nama;
    private String location;
    private String company;
    private String public_repos;
    private String followers;
    private String following;
    private Long id;
    private Uri uriWithId;
    private FavoriteHelper favoriteHelper;
    Boolean favorite = false;

    public DetailActivity() {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        imgAvatar = findViewById(R.id.img_avatar_detail);
        tvUsername = findViewById(R.id.tv_username_detail);
        tvName = findViewById(R.id.tv_name_detail);
        tvLocation = findViewById(R.id.tv_location_detail);
        tvFollowers = findViewById(R.id.tv_followers);
        tvFollowing = findViewById(R.id.tv_following);
        tvCompany = findViewById(R.id.tv_company_detail);
        tvRepository = findViewById(R.id.tv_repository_detail);

        Bundle bundle = getIntent().getBundleExtra(UserAdapter.DATA_EXTRA);

        dataUser = Parcels.unwrap(Objects.requireNonNull(bundle).getParcelable(UserAdapter.DATA_USER));

        favoriteHelper = FavoriteHelper.getInstance(getApplicationContext());
        favoriteHelper.open();

        btnAddFavorite = findViewById(R.id.btn_add_favorite);

        uriWithId = Uri.parse(String.valueOf(CONTENT_URI));

        checkFavorite();

        loadData();
        tabLayout();
        actionBar();
    }


    public void loadData() {
        final ProgressDialog progress = new ProgressDialog(DetailActivity.this);
        progress.setMessage(getString(R.string.loading));
        progress.show();

        Glide.with(DetailActivity.this)
                .load(dataUser.getAvatarUrl())
                .into(imgAvatar);
        tvUsername.setText(dataUser.getLogin());

        Call<DetailModel> request = ApiClient.getApiService().getDetailUser(dataUser.getLogin());
        request.enqueue(new Callback<DetailModel>() {
            @Override
            public void onResponse(@NotNull Call<DetailModel> call, @NotNull Response<DetailModel> response) {
                llLocation = findViewById(R.id.ll_location);
                llCompany = findViewById(R.id.ll_company);

                dataDetailUser = response.body();
                id = dataDetailUser.getId();
                nama = dataDetailUser.getName();
                location = dataDetailUser.getLocation();
                company = dataDetailUser.getCompany();
                public_repos = dataDetailUser.getPublic_repos();
                followers = dataDetailUser.getFollowers();
                following = dataDetailUser.getFollowing();

                if (company == null) {
                   llCompany.setVisibility(View.GONE);
                } else {
                    tvCompany.setText(company);
                }

                if (location== null) {
                    llLocation.setVisibility(View.GONE);
                } else {
                    tvLocation.setText(location);
                }

                tvName.setText(nama);
                tvFollowers.setText(followers);
                tvFollowing.setText(following);
                tvRepository.setText(public_repos);
                progress.dismiss();

                btnAddFavorite.setOnClickListener(view -> {
                    if(favorite){
                        removeFavorite(dataUser.getLogin());
                    }
                    else{
                        addFavorite(dataDetailUser);
                    }
                    favorite =!favorite;
                    setFavorite();
                });
            }

            @Override
            public void onFailure(@NotNull Call<DetailModel> call, @NotNull Throwable t) {
            }
        });
    }

    private void setFavorite() {
        if(favorite){
            btnAddFavorite.setBackgroundResource(R.drawable.ic_add_favorite);
        }
        else{
            btnAddFavorite.setBackgroundResource(R.drawable.ic_delete_favorite);
        }
    }

    private void removeFavorite(String login) {
        favoriteHelper.deleteById(login);
        getContentResolver().delete(uriWithId, null, null);
        Toast.makeText(this, "Berhasil Dihapus", Toast.LENGTH_SHORT).show();
    }

    private void addFavorite(DetailModel dataDetailUser) {
        ContentValues values = new ContentValues();
        values.put(ID_USER, dataDetailUser.getId());
        values.put(LOGIN, dataUser.login);
        values.put(AVATAR_URL, dataUser.getAvatarUrl());

        getContentResolver().insert(CONTENT_URI, values);

        Toast.makeText(this, "Berhasil Ditambahkan", Toast.LENGTH_SHORT).show();
    }


    private void actionBar() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(R.string.detail_user);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
    }

    private void tabLayout() {
        SectionsPagerAdapter sectionsPagerAdapter = new SectionsPagerAdapter(this, getSupportFragmentManager());
        ViewPager viewPager = findViewById(R.id.view_pager);
        viewPager.setAdapter(sectionsPagerAdapter);
        TabLayout tabLayout = findViewById(R.id.tab_layout);
        tabLayout.setupWithViewPager(viewPager);
    }


    private void checkFavorite() {
        String login = dataUser.getLogin();
        if (favoriteHelper.checkUserGithub(login)) {
            favorite = true;
            btnAddFavorite.setBackgroundResource(R.drawable.ic_add_favorite);
        } else if (!favoriteHelper.checkUserGithub(login)) {
            favorite = false;
            btnAddFavorite.setBackgroundResource(R.drawable.ic_delete_favorite);
        }
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}