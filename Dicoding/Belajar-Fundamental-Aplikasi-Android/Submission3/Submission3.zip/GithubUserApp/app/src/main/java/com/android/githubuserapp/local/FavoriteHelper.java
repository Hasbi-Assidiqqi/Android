package com.android.githubuserapp.local;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import static android.provider.BaseColumns._ID;
import static com.android.githubuserapp.local.DatabaseContract.FavoritesColumns.LOGIN;

public class FavoriteHelper {
    private static final String DATABASE_TABLE = DatabaseContract.FavoritesColumns.TABLE_NAME;
    private static DatabaseHelper databaseHelper;
    private static FavoriteHelper INSTANCE;

    private static SQLiteDatabase database;

    private FavoriteHelper(Context context){
        databaseHelper = new DatabaseHelper(context);
    }

    public static FavoriteHelper getInstance(Context context){
        if(INSTANCE == null){
            synchronized (SQLiteOpenHelper.class){
                if(INSTANCE == null){
                    INSTANCE = new FavoriteHelper(context);
                }
            }
        }
        return INSTANCE;
    }

    public void open() throws SQLException{
        database = databaseHelper.getWritableDatabase();
    }

    //buat nampilin semua data
    public Cursor queryAll(){
        return database.query(
                DATABASE_TABLE,
                null,
                null,
                null,
                null,
                null,
                _ID + " ASC");
    }
    //buat nampilin berdasarkan id
    public Cursor queryById(String id){
        return database.query(
                DATABASE_TABLE,
                null,
                _ID + "= ?",
                new String[]{id},
                null,
                null,
                null,
               null
        );
    }

    //buat menambahkan
    public long insert(ContentValues values){
        return database.insert(DATABASE_TABLE, null, values);
    }
    //buat update
    public int update (String id, ContentValues values){
        return database.update(DATABASE_TABLE, values, _ID +"=", new String[]{id});
    }
    //buat delete
    public int deleteById(String id){
        return database.delete(DATABASE_TABLE, LOGIN + "= '" + id + "';", null);
    }

    //baca data
    public boolean checkUserGithub(String username){
        boolean loadCount;
        Cursor cursor = database.query(
                DATABASE_TABLE,
                null,
                LOGIN + "= ?",
                new String[]{username},
                null,
                null,
                null,
                "1"
        );
        cursor.moveToFirst();
        if(loadCount = cursor.getCount() > 0){
            if(cursor.moveToFirst()){
                return true;
            }
            cursor.close();
        }
        return loadCount;
    }

}
