package com.android.githubuserapp.local;

import android.net.Uri;
import android.provider.BaseColumns;

public class DatabaseContract {

    public static final String AUTHORITY = "com.android.githubuserapp";
    private static final String SCHEME = "content";

    private DatabaseContract(){}

    public static final class FavoritesColumns implements BaseColumns {
        public static String TABLE_NAME = "favorites";
        public static String ID_USER = "ID_USER";
        public static String LOGIN = "LOGIN";
        public static String AVATAR_URL = "AVATAR_URL";

        public static final Uri CONTENT_URI = new Uri.Builder().scheme(SCHEME)
                .authority(AUTHORITY)
                .appendPath(TABLE_NAME)
                .build();

    }




}
