package com.android.githubuserapp.helper;

import android.database.Cursor;

import com.android.githubuserapp.model.UserModel;

import java.util.ArrayList;

import static com.android.githubuserapp.local.DatabaseContract.FavoritesColumns.AVATAR_URL;
import static com.android.githubuserapp.local.DatabaseContract.FavoritesColumns.ID_USER;
import static com.android.githubuserapp.local.DatabaseContract.FavoritesColumns.LOGIN;

public class MappingHelper {
    public static ArrayList<UserModel> mapCursorToArrayList(Cursor favs) {
        ArrayList<UserModel> favList = new ArrayList<>();
        while (favs.moveToNext()) {
            Long userId = favs.getLong(favs.getColumnIndexOrThrow(ID_USER));
            String username = favs.getString(favs.getColumnIndexOrThrow(LOGIN));
            String avatar_url = favs.getString(favs.getColumnIndexOrThrow(AVATAR_URL));
            favList.add(new UserModel(userId, username, avatar_url));
        }
        return favList;
    }

}
