package com.android.githubuserapp.consumerapp.activity;

import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.android.githubuserapp.consumerapp.AlarmReceiver;
import com.android.githubuserapp.consumerapp.R;
import com.android.githubuserapp.consumerapp.adapter.UserAdapter;
import com.android.githubuserapp.consumerapp.api.ApiClient;
import com.android.githubuserapp.consumerapp.model.ResponseUser;
import com.android.githubuserapp.consumerapp.model.UserModel;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    ArrayList<UserModel> dataGithub = new ArrayList<>();
    RecyclerView rvUser;
    private static long backPressed;
    private ProgressBar progressBar;
    private ImageView imageView;
    private AlarmReceiver alarmReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        progressBar = findViewById(R.id.progressBar);
        imageView = findViewById(R.id.image);
        rvUser = findViewById(R.id.rv_search_user);

        alarmReceiver = new AlarmReceiver();

        actionBar();
        searchView();
    }

    private void actionBar() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(R.string.app_name);
            getSupportActionBar().setDisplayHomeAsUpEnabled(false);
            getSupportActionBar().setDisplayShowHomeEnabled(false);
        }
    }

    private void searchView() {
        rvUser.setLayoutManager(new LinearLayoutManager(MainActivity.this));

        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        if (searchManager != null) {
            final SearchView searchView = findViewById(R.id.searcView);
            searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
            searchView.setQueryHint(getResources().getString(R.string.search));
            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String string) {
                    showProgress(true);
                    if (string.isEmpty()) {
                        Toast.makeText(MainActivity.this, R.string.desc_empty, Toast.LENGTH_SHORT).show();
                    } else {
                        getDataOnline(string);
                        closeKeyboard();
                    }
                    return true;
                }

                @Override
                public boolean onQueryTextChange(String s) {
                    return true;
                }
            });
        }
    }

    private void showProgress(Boolean state) {
        if (state) {
            progressBar.setVisibility(View.VISIBLE);
            rvUser.setVisibility(View.GONE);
        } else {
            progressBar.setVisibility(View.GONE);
            rvUser.setVisibility(View.VISIBLE);
        }
        imageView.setVisibility(View.GONE);
    }

    private void getDataOnline(String usernames) {
        Call<ResponseUser> request = ApiClient.getApiService().getSearchUser(usernames);
        request.enqueue(new Callback<ResponseUser>() {
            @Override
            public void onResponse(@NotNull Call<ResponseUser> call, @NotNull Response<ResponseUser> response) {
                if (response.isSuccessful()) {
                    dataGithub = new ArrayList<>(response.body().getItems());
                    rvUser.setAdapter(new UserAdapter(MainActivity.this, dataGithub));
                    showProgress(false);
                } else {
                    Toast.makeText(MainActivity.this, R.string.desc_not_succes, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(@NotNull Call<ResponseUser> call, @NotNull Throwable t) {
                Toast.makeText(MainActivity.this, "Request Failure" + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (backPressed + 1000 > System.currentTimeMillis()) {
            super.onBackPressed();
            finish();
        } else {
            Toast.makeText(getBaseContext(), R.string.desc_press_again, Toast.LENGTH_SHORT).show();
        }
        backPressed = System.currentTimeMillis();
    }

    private void closeKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager inputMethodManager = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.swt_reminder) {
            if (item.isChecked()) {
                alarmReceiver.cancelAlarm(getApplicationContext());
                Toast.makeText(MainActivity.this, R.string.repeat_alaram_off, Toast.LENGTH_SHORT).show();
                item.setChecked(false);
            } else {
                alarmReceiver.setRepeatingAlarm(getApplicationContext());
                Toast.makeText(MainActivity.this, R.string.repeat_alaram_on, Toast.LENGTH_SHORT).show();
                item.setChecked(true);
            }
        } else if (item.getItemId() == R.id.action_change_language) {
            Intent mIntent = new Intent(Settings.ACTION_LOCALE_SETTINGS);
            startActivity(mIntent);
        } else if (item.getItemId() == R.id.action_about) {
            Intent moveInfo = new Intent(MainActivity.this, InfoActivity.class);
            startActivity(moveInfo);
        } else if (item.getItemId() == R.id.action_favorite) {
            Intent favoriteIntent = new Intent(MainActivity.this, FavoriteActivity.class);
            startActivity(favoriteIntent);
        }

        return super.onOptionsItemSelected(item);
    }
}
