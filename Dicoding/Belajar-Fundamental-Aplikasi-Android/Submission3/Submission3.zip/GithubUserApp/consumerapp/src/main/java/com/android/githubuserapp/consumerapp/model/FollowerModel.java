package com.android.githubuserapp.consumerapp.model;

import com.google.gson.annotations.SerializedName;

public class FollowerModel{

	@SerializedName("id")
	private int id;

	@SerializedName("login")
	private final String login;

	@SerializedName("avatar_url")
	private final String avatarUrl;


	public void setId(int id){
		this.id = id;
	}

	public int getId(){
		return id;
	}

	public String getLogin(){
		return login;
	}

	public String getAvatarUrl(){
		return avatarUrl;
	}


	public FollowerModel(int id, String login, String avatarUrl) {
		this.id = id;
		this.login = login;
		this.avatarUrl = avatarUrl;
	}
}