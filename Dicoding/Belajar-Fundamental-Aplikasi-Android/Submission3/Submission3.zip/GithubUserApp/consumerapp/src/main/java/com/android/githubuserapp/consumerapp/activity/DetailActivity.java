package com.android.githubuserapp.consumerapp.activity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.android.githubuserapp.consumerapp.R;
import com.android.githubuserapp.consumerapp.adapter.SectionsPagerAdapter;
import com.android.githubuserapp.consumerapp.adapter.UserAdapter;
import com.android.githubuserapp.consumerapp.api.ApiClient;
import com.android.githubuserapp.consumerapp.model.DetailModel;
import com.android.githubuserapp.consumerapp.model.UserModel;
import com.bumptech.glide.Glide;
import com.google.android.material.tabs.TabLayout;

import org.jetbrains.annotations.NotNull;
import org.parceler.Parcels;

import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class DetailActivity extends AppCompatActivity {
    DetailModel dataDetailUser;
    UserModel dataUser;
    LinearLayout llLocation, llCompany;
    TextView tvName, tvUsername, tvFollowers, tvFollowing, tvLocation, tvCompany, tvRepository;
    ImageView imgAvatar;
    ImageButton btnAddFavorite;

    private String nama;
    private String location;
    private String company;
    private String public_repos;
    private String followers;
    private String following;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        imgAvatar = findViewById(R.id.img_avatar_detail);
        tvUsername = findViewById(R.id.tv_username_detail);
        tvName = findViewById(R.id.tv_name_detail);
        tvLocation = findViewById(R.id.tv_location_detail);
        tvFollowers = findViewById(R.id.tv_followers);
        tvFollowing = findViewById(R.id.tv_following);
        tvCompany = findViewById(R.id.tv_company_detail);
        tvRepository = findViewById(R.id.tv_repository_detail);

        Bundle bundle = getIntent().getBundleExtra(UserAdapter.DATA_EXTRA);

        dataUser = Parcels.unwrap(Objects.requireNonNull(bundle).getParcelable(UserAdapter.DATA_USER));


        btnAddFavorite = findViewById(R.id.btn_add_favorite);


        loadData();
        tabLayout();
        actionBar();
    }


    public void loadData() {

        final ProgressDialog progress = new ProgressDialog(DetailActivity.this);
        progress.setMessage(getString(R.string.loading));
        progress.show();

        String avatar_url = dataUser.getAvatarUrl();

        Glide.with(DetailActivity.this)
                .load(avatar_url)
                .into(imgAvatar);
        tvUsername.setText(dataUser.getLogin());

        Call<DetailModel> request = ApiClient.getApiService().getDetailUser(dataUser.getLogin());
        request.enqueue(new Callback<DetailModel>() {
            @Override
            public void onResponse(@NotNull Call<DetailModel> call, @NotNull Response<DetailModel> response) {
                llLocation = findViewById(R.id.ll_location);
                llCompany = findViewById(R.id.ll_company);

                dataDetailUser = response.body();
                nama = dataDetailUser.getName();
                location = dataDetailUser.getLocation();
                company = dataDetailUser.getCompany();
                public_repos = dataDetailUser.getPublic_repos();
                followers = dataDetailUser.getFollowers();
                following = dataDetailUser.getFollowing();


                if (company == null) {
                    llCompany.setVisibility(View.GONE);
                } else {
                    tvCompany.setText(company);
                }

                if (location== null) {
                    llLocation.setVisibility(View.GONE);
                } else {
                    tvLocation.setText(location);
                }

                tvName.setText(nama);
                tvFollowers.setText(followers);
                tvFollowing.setText(following);
                tvRepository.setText(public_repos);
                progress.dismiss();
            }

            @Override
            public void onFailure(@NotNull Call<DetailModel> call, @NotNull Throwable t) {
            }
        });
    }


    private void actionBar() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(R.string.detail_user);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
    }

    private void tabLayout() {
        SectionsPagerAdapter sectionsPagerAdapter = new SectionsPagerAdapter(this, getSupportFragmentManager());
        ViewPager viewPager = findViewById(R.id.view_pager);
        viewPager.setAdapter(sectionsPagerAdapter);
        TabLayout tabLayout = findViewById(R.id.tab_layout);
        tabLayout.setupWithViewPager(viewPager);
    }

}