package com.android.githubuserapp.consumerapp.activity;

import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.githubuserapp.consumerapp.R;
import com.android.githubuserapp.consumerapp.adapter.UserAdapter;
import com.android.githubuserapp.consumerapp.helper.MappingHelper;
import com.android.githubuserapp.consumerapp.local.DatabaseContract;
import com.android.githubuserapp.consumerapp.model.UserModel;
import com.google.android.material.snackbar.Snackbar;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

public class FavoriteActivity extends AppCompatActivity implements LoadFavCallback{
    private UserAdapter userAdapter;
    private final ArrayList<UserModel> userModels = new ArrayList<>();
    private RecyclerView rvFavUser;
    private static final String EXTRA_STATE = "EXTRA_STATE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorite);

        actionBar();

        rvFavUser = findViewById(R.id.rv_favorite);

        userAdapter = new UserAdapter(this, userModels);

        rvFavUser.setHasFixedSize(true);
        rvFavUser.setLayoutManager(new LinearLayoutManager(this));
        userAdapter.setDataUser(userModels);
        rvFavUser.setAdapter(userAdapter);

        HandlerThread handlerThread = new HandlerThread("DataObserver");
        handlerThread.start();
        Handler handler = new Handler(handlerThread.getLooper());

        DataObserver myObserver = new DataObserver(handler, this);
        getContentResolver().registerContentObserver(DatabaseContract.FavoritesColumns.CONTENT_URI, true, myObserver);

        if(savedInstanceState == null){
            new LoadFavAsync(this, this).execute();
        }
        else{
            ArrayList<UserModel> list = savedInstanceState.getParcelableArrayList(EXTRA_STATE);
            if(list != null){
               userAdapter.setDataUser(list);
            }
        }
    }

    private void showSnackbarMessage() {
        Snackbar.make(rvFavUser, R.string.not_item, Snackbar.LENGTH_SHORT).show();
    }

    private static class LoadFavAsync extends AsyncTask<Void, Void, List<UserModel>>{
        private final WeakReference<Context> weakContext;
        private final WeakReference<LoadFavCallback> weakCallback;

        private LoadFavAsync(Context context, LoadFavCallback loadCallback) {
            weakContext = new WeakReference<>(context);
            weakCallback = new WeakReference<>(loadCallback);
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            weakCallback.get().preExecute();
        }

        @Override
        protected ArrayList<UserModel> doInBackground(Void... voids) {
            Context context = weakContext.get();
            Cursor dataCursor = context.getContentResolver().query(DatabaseContract.FavoritesColumns.CONTENT_URI, null, null, null, null);
            return MappingHelper.mapCursorToArrayList(dataCursor);
        }

        @Override
        protected void onPostExecute(List<UserModel> userModels) {
            super.onPostExecute(userModels);
            weakCallback.get().postExecute(userModels);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void preExecute() {
    }

    @Override
    public void postExecute(List<UserModel> favorites) {
        if(favorites.size() > 0){
            userAdapter.setDataUser(favorites);
        }
        else{
            userAdapter.setDataUser(new ArrayList<>());
            showSnackbarMessage();
        }
    }

    public static class DataObserver extends ContentObserver{
        final Context context;

        public DataObserver(Handler handler, Context context) {
            super(handler);
            this.context = context;
        }

        @Override
        public void onChange(boolean selfChange) {
            super.onChange(selfChange);
            new LoadFavAsync(context, (LoadFavCallback)context).execute();
        }
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelableArrayList(EXTRA_STATE, userAdapter.getData());
    }

    private void actionBar() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(R.string.favorite);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
    }
}

interface LoadFavCallback{
    void preExecute();
    void postExecute(List<UserModel> favorites);
}