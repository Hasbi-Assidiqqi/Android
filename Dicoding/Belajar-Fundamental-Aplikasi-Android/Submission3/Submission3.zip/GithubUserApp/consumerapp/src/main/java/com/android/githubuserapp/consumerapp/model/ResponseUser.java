package com.android.githubuserapp.consumerapp.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ResponseUser{

	@SerializedName("items")
	private final List<UserModel> items;


	public List<UserModel> getItems(){
		return items;
	}


	public ResponseUser(List<UserModel> items) {
		this.items = items;
	}
}