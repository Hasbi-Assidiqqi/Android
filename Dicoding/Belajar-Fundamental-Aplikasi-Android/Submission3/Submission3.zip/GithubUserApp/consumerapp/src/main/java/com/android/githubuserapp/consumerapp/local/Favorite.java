package com.android.githubuserapp.consumerapp.local;

import android.os.Parcel;
import android.os.Parcelable;

public class Favorite implements Parcelable {
    Long id;
    String login, name, location, company, public_repos, avatar_url;

    protected Favorite(Parcel in) {
        if (in.readByte() == 0) {
            id = null;
        } else {
            id = in.readLong();
        }
        login = in.readString();
        name = in.readString();
        location = in.readString();
        company = in.readString();
        public_repos = in.readString();
        avatar_url = in.readString();
    }

    public static final Creator<Favorite> CREATOR = new Creator<Favorite>() {
        @Override
        public Favorite createFromParcel(Parcel in) {
            return new Favorite(in);
        }

        @Override
        public Favorite[] newArray(int size) {
            return new Favorite[size];
        }
    };

    public long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        if (id == null) {
            parcel.writeByte((byte) 0);
        } else {
            parcel.writeByte((byte) 1);
            parcel.writeLong(id);
        }
        parcel.writeString(login);
        parcel.writeString(name);
        parcel.writeString(location);
        parcel.writeString(company);
        parcel.writeString(public_repos);
        parcel.writeString(avatar_url);
    }
}
